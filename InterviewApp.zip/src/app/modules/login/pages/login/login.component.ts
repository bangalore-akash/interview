import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  fullImagePath: string;
  show: boolean;

  loginUserPostData: any = {
    userid: "",
    password: "",
  };

  constructor(private router: Router,) {}

  ngOnInit() {}

  html() {
    this.router.navigate(['user/html']);
  }
  css() {
    this.router.navigate(['user/css']);
  }
  angular() {
    this.router.navigate(['user/angular']);
  }
  javascript() {
    this.router.navigate(['user/javascript']);
  }
}
