import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-questions-answers',
  templateUrl: './questions-answers.component.html',
  styleUrls: ['./questions-answers.component.css']
})
export class QuestionsAnswersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
