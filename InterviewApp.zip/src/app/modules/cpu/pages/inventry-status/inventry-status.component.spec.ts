import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventryStatusComponent } from './inventry-status.component';

describe('InventryStatusComponent', () => {
  let component: InventryStatusComponent;
  let fixture: ComponentFixture<InventryStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InventryStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventryStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
