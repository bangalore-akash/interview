import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventry-status',
  templateUrl: './inventry-status.component.html',
  styleUrls: ['./inventry-status.component.css']
})
export class InventryStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
