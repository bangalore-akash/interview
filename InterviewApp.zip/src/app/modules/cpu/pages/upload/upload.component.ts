import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  
  constructor(private router: Router) { }

  row = [
    {
      state: '',
      agrSlNoFrom: '',
      agrSlNoTo: '',
      totalCount: ''
    }
  ]
  rowCount: number;

  ngOnInit() {
  }

  addRow(){
    const obj = {
      state: '',
      agrSlNoFrom: '',
      agrSlNoTo: '',
      totalCount: ''
    }
    this.row.push(obj);
    this.rowCount = this.row.length;
    console.log(this.row);
    
  }

  delRow(index){
    this.row.splice(index, 1);
    this.rowCount = this.row.length;
  }

  viewAll(){
    this.router.navigate(['user/cpu/inventryStatus']);
  }

}
