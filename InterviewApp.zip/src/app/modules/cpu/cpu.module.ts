import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CpuRoutingModule } from "./cpu-routing.module";
import { DashboardComponent } from "./pages/dashboard/dashboard.component";
import { SharedModule } from "src/app/shared/shared.module";
import { UploadComponent } from "./pages/upload/upload.component";
import { InventryStatusComponent } from "./pages/inventry-status/inventry-status.component";
import { AllocationComponent } from "./pages/allocation/allocation.component";
import { AllocationStatusComponent } from "./pages/allocation-status/allocation-status.component";

@NgModule({
  declarations: [
    DashboardComponent,
    UploadComponent,
    InventryStatusComponent,
    AllocationComponent,
    AllocationStatusComponent,
  ],
  imports: [CommonModule, CpuRoutingModule, SharedModule],
})
export class CpuModule {}
