import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { CommonModule } from '@angular/common';
import { UploadComponent } from './pages/upload/upload.component';
import { InventryStatusComponent } from './pages/inventry-status/inventry-status.component';
import { AllocationComponent } from './pages/allocation/allocation.component';
import { AllocationStatusComponent } from './pages/allocation-status/allocation-status.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'uplod',
    component: UploadComponent
  },
  {
    path: 'inventryStatus',
    component: InventryStatusComponent
  },
  {
    path: 'allocation',
    component: AllocationComponent
  },
  {
    path: 'allocationStatus',
    component: AllocationStatusComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CpuRoutingModule { }
