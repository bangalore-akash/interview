import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProgramsComponent } from './pages/programs/programs.component';
import { QuestionsAnswersComponent } from './pages/questions-answers/questions-answers.component';

const routes: Routes = [
  {
    path: '',
    component: QuestionsAnswersComponent
  },
  {
    path: 'QuestionsAnswers',
    component: QuestionsAnswersComponent
  },
  {
    path: 'Programs',
    component: ProgramsComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CssRoutingModule { }
