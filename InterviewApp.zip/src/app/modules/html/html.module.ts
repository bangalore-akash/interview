import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HtmlRoutingModule } from './html-routing.module';
import { QuestionsAnswersComponent } from './pages/questions-answers/questions-answers.component';
import { ProgramsComponent } from './pages/programs/programs.component';

@NgModule({
  declarations: [QuestionsAnswersComponent, ProgramsComponent],
  imports: [
    CommonModule,
    HtmlRoutingModule
  ]
})
export class HtmlModule { }
