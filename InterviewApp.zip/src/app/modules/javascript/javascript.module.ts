import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { JavascriptRoutingModule } from "./javascript-routing.module";
import { QuestionsAnswersComponent } from "./pages/questions-answers/questions-answers.component";
import { ProgramsComponent } from './pages/programs/programs.component';

@NgModule({
  declarations: [QuestionsAnswersComponent, ProgramsComponent],
  imports: [CommonModule, JavascriptRoutingModule],
})
export class JavascriptModule {}
