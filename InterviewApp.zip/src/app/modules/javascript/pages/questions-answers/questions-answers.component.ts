import { Component, OnInit } from "@angular/core";
import { of } from "rxjs";
import { catchError, tap } from "rxjs/operators";
import { ApiService } from "src/app/core/services/api/api.service";

@Component({
  selector: "app-questions-answers",
  templateUrl: "./questions-answers.component.html",
  styleUrls: ["./questions-answers.component.css"],
})
export class QuestionsAnswersComponent implements OnInit {
  apiUrl = "/assets/data/jsQA.json";
  jsQAdata: any;
  constructor(private apiservice: ApiService) {}

  ngOnInit() {
    this.getQA();
  }

  getQA() {
    this.apiservice
      .get(this.apiUrl)
      .pipe(
        tap((response) => {
          this.jsQAdata = response
        }),
        catchError((error) => of(this.errorCall(error)))
      )
      .subscribe();
  }

  errorCall(error) {
    console.log(error);
  }
}
