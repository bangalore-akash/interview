import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReactjsRoutingModule } from './reactjs-routing.module';
import { QuestionsAnswersComponent } from './pages/questions-answers/questions-answers.component';
import { ProgramsComponent } from './pages/programs/programs.component';

@NgModule({
  declarations: [QuestionsAnswersComponent, ProgramsComponent],
  imports: [
    CommonModule,
    ReactjsRoutingModule
  ]
})
export class ReactjsModule { }
