import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    { 
        path: 'login', 
        loadChildren: 'src/app/modules/login/login.module#LoginModule'
    },
    { 
        path: 'html', 
        loadChildren: 'src/app/modules/html/html.module#HtmlModule'
    },
    { 
        path: 'css', 
        loadChildren: 'src/app/modules/css/css.module#CssModule'
    },
    { 
        path: 'javascript', 
        loadChildren: 'src/app/modules/javascript/javascript.module#JavascriptModule'
    },
    { 
        path: 'reactjs', 
        loadChildren: 'src/app/modules/reactjs/reactjs.module#ReactjsModule'
    },
    { 
        path: 'angular', 
        loadChildren: 'src/app/modules/angular/angular.module#AngularModule'
    },
    { 
        path: 'cpu',
        loadChildren: 'src/app/modules/cpu/cpu.module#CpuModule'
    },
]