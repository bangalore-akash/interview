import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-nav",
  templateUrl: "./nav.component.html",
  styleUrls: ["./nav.component.css"],
})
export class NavComponent implements OnInit {
  stackicon = "/assets/images/logo.png";
  activeURL: string;
  isOpen: boolean;

  constructor(private router: Router) {
    this.router.events.subscribe((res) => {
      this.activeURL = this.router.url;
    });
  }


  ngOnInit() {console.log(this.activeURL);}
  toggleMenu(){
    this.isOpen = !this.isOpen
  }
}
